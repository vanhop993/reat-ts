export enum ModelStatus {
  Active = 'A',
  Inactive = 'I'
}
