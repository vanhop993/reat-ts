import * as React from 'react';
import {HistoryProps} from 'react-onex';
import {storage, StringMap} from 'uione';
import {PlaylistVideo} from 'video-plus';
import {context} from './app';

interface PlaylistState {
  id?: string;
  title?: string;
  description?: string;
  videos: PlaylistVideo[];
}

export class PlaylistForm extends React.Component<HistoryProps, PlaylistState> {
  constructor(props: HistoryProps) {
    super(props);
    this.resource = storage.resource().resource();
    this.getPlaylist = context.videoService.getPlaylist;
    this.state = {
      videos: []
    };
  }
  protected resource: StringMap = {};
  protected getPlaylist: (playlistId: string, max?: number) => Promise<PlaylistVideo[]>;

  componentWillMount() {
    const sp = (this.props.match ? this.props : this.props['props']);
    const id = sp.match.params['id'];
    this.getPlaylist(id).then(videos => this.setState({videos}));
  }

  render() {
    const resource = this.resource;
    const {videos} = this.state;
    return (
      <div className='view-container'>
        <form id='playlistForm' name='playlistForm'>
          <header>
            <h2 className='label'>{resource.welcome_title}</h2>
          </header>
          <div>
            <ul className='row list-view'>
              {videos && videos.map((item, i) => {
                return (
                  <li key={i} className='col s12 m6 l4 xl3 card'>
                    <section>
                      <img src={item.highThumbnail} className='cover'/>
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                    </section>
                  </li>
                );
              })}
            </ul>
          </div>
        </form>
      </div>
    );
  }
}
