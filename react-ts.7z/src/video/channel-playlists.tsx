import * as React from 'react';
import {HistoryProps} from 'react-onex';
import {storage, StringMap} from 'uione';
import {Playlist} from 'video-plus';
import {context} from './app';

interface PlaylistsState {
  channelId?: string;
  channelTitle?: string;
  playlists: Playlist[];
}

export class ChannelPlaylistForm extends React.Component<HistoryProps, PlaylistsState> {
  constructor(props: HistoryProps) {
    super(props);
    this.resource = storage.resource().resource();
    this.getPlaylists = context.videoService.getPlaylists;
    this.state = {
      playlists: []
    };
  }
  protected resource: StringMap = {};
  protected getPlaylists: (channelId: string, max?: number) => Promise<Playlist[]>;

  componentWillMount() {
    this.getPlaylists('UCBkqDNqao03ldC3u78-Pp8g').then(playlists => this.setState({playlists}));
  }
  view = (e: any, id: string) => {
    e.preventDefault();
    this.props.history.push(`channel/playlist/${id}`);
  }
  render() {
    const resource = this.resource;
    const {playlists} = this.state;
    return (
      <div className='view-container'>
        <form id='playlistsForm' name='playlistsForm'>
          <header>
            <h2>{resource.welcome_title}</h2>
          </header>
          <div>
            <ul className='row list-view'>
              {playlists && playlists.map((item, i) => {
                return (
                  <li key={i} className='col s12 m6 l4 xl3 card'>
                    <section>
                      <img src={item.highThumbnail} className='cover' onClick={e => this.view(e, item.id)}/>
                      <h3>{item.title}</h3>
                      <p>{item.description}</p>
                    </section>
                  </li>
                );
              })}
            </ul>
          </div>
        </form>
      </div>
    );
  }
}
